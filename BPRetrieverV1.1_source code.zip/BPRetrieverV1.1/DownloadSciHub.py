import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
import os
import re
from openpyxl import load_workbook
import time
from bs4 import BeautifulSoup



def DownloadSciHub(file,event,YearMin,YearMax,Website,i,pathOutput):#下载
    if event == 'Download2':
        pathOutput= pathOutput + "pubmed\\"
    if event == 'Download3':
        pathOutput = pathOutput + "wos\\"
    if event == 'Download4':
        pathOutput= pathOutput + "doi_Download\\"
        # 打开excel
        filename = file
        print("打开文件", filename)
        excel = load_workbook(pathOutput + file)
        table = excel.worksheets[0]  # 获取sheet

        rows = table.max_row  # 获取行数
        cols = table.max_column  # 获取列数
        success = 0
        j = 0
        i= 1
        for row in range(1, rows + 1):
            DOI = str(table.cell(row=row, column=1).value)
            Title = "doi" + str(i) + ".pdf"
            if table.cell(row=row, column=1).value != None:
                if table.cell(row=row, column=2).value != "下载成功":
                    doi = DOI.split("http://dx.doi.org/")[-1]
                    i = i + 1
                    j = j + 1
                    print("正在下载第", i-1, "篇文章：", Title)
                    # 开始下载
                    if os.path.exists(Title) == False:
                        pdf_url = get_pdf_url(doi, Website)  # 下载1
                        if download_pdf(pdf_url, Title, pathOutput) == 1:  # 下载2
                            success = success + 1
                            table.cell(row=row, column=2).value = "下载成功"
                        else:
                            table.cell(row=row, column=2).value = "下载失败"
                else:
                    print("跳过一篇之前下载过的文章")
            excel.save(pathOutput + filename)
        Text = str(success) + "篇下载成功," + str(j - success) + "篇下载失败\n"
        return Text, i

    if not os.path.exists(pathOutput):  # 判断是否存在文件夹如果不存在则创建为文件夹
        os.makedirs(pathOutput)
    # 打开excel
    filename = file
    print("\n打开文件", filename)
    excel = load_workbook(pathOutput+ filename )
    table = excel.worksheets[0] # 获取sheet
    rows = table.max_row  # 获取行数
    cols = table.max_column  # 获取列数
    success = 0
    j = 0
    for row in range(1,rows+1):
        Title = str(table.cell(row=row, column=1).value)
        Date = str(table.cell(row=row, column=4).value)[0:4]
        DOI = str(table.cell(row=row, column=7).value)
        Title = Date +"_"+ " ".join(Title.split(" ")[0:10])+".pdf"
        Title = re.sub(r'[^A-Za-z0-9 ._]+', ' ', Title)
        if DOI.find("http") == 0:
            if (int(Date) <= int(YearMax) and int(Date) >= int(YearMin)):
                if table.cell(row=row, column=8).value != "下载成功":
                    doi = DOI.split("http://dx.doi.org/")[-1]
                    i = i + 1
                    j= j + 1
                    print("正在下载第",i,"篇文章：",Title)
                    #开始下载
                    if len(Title) > 200:
                        Title = Title[0:190] + ".pdf"
                    if os.path.exists(Title) == False:
                        pdf_url = get_pdf_url(doi,Website)#下载1
                        if download_pdf(pdf_url,Title,pathOutput) == 1: #下载2
                            success = success +1
                            table.cell(row=row, column=8).value = "下载成功"
                        else:
                            table.cell(row=row, column=8).value = "下载失败"
                else:
                    print( "跳过一篇之前下载过的文章")
            else:
                 print("第"+str(row)+"行,跳过一篇不在下载年份内的文章")

        excel.save(pathOutput + filename )

    Text = "关键词“" + filename[:-4] + "”," + str(success) + "篇下载成功," + str(j - success) + "篇下载失败\n"
    return Text,i



def get_pdf_url(doi, base_url, user_agent="siebe", proxies=None, num_retries=2,):#下载1
    global url
    headers = {'User-Agent': user_agent}
    url = base_url + doi
    try:
        response = requests.get(url, headers=headers, proxies=proxies, verify=False)
        if response.status_code != 200:
            return get_pdf_url(doi, user_agent, proxies, num_retries - 1)
        soup = BeautifulSoup(response.text, "html.parser")
        try:
            pdf_url = soup.find("iframe")["src"].replace("#view=FitH", "")
        except:
            return None
        if "http" not in pdf_url:
            pdf_url = "http:" + pdf_url
    except requests.exceptions.RequestException as e:
        print('get_pdf_url error', e)
        return None
    return pdf_url

def download_pdf(pdf_url,Title,pathOutput,user_agent="siebe"):#下载2
    headers = {'User-Agent': user_agent}
    try:
        r = requests.get(pdf_url, verify=True)
        with open(pathOutput+Title, "wb+") as fp:
            fp.write(r.content)
        print ("下载成功！ (url：",url,")")
        return 1
    except requests.exceptions.RequestException as e:
        print ("下载失败 (url：",url,")")
        return 0