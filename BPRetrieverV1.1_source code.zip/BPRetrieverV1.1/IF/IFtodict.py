import os
from openpyxl import load_workbook

excelIF = load_workbook(os.getcwd() + "/IF2020.xlsx")#输入文件所在目录
tableIF = excelIF.worksheets[0]  # 获取sheet
IFdict = {}

rows = tableIF.max_row  # 获取行数
for row in range(3, rows + 1):
    Name=tableIF.cell(row=row, column = 2).value
    IF = tableIF.cell(row=row, column=6).value
    if Name != None and IF != None:
        IFdict.update({Name.title(): IF})

f = open (r'IF2020.txt', 'w')
print(IFdict, file = f)
f.close()