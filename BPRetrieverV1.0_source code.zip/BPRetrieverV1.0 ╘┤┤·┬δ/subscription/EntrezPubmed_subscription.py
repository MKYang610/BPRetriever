from Bio import Entrez
from Bio import Medline
import datetime
from openpyxl import Workbook
from openpyxl import load_workbook
import re
import os
from IF.IF2020 import *

def get_row_value(self, row):
    columns = self.max_column
    row_data = []
    for i in range(1, columns + 1):
        cell_value = self.cell(row=row, column=i).value
        row_data.append(cell_value)
    return row_data

def EntrezPubmed_subscription(TermName,TimeNow,Relday,email,pathOutput):#检索
    if not os.path.exists(pathOutput + "/subscription"):  # 判断是否存在文件夹如果不存在则创建为文件夹
        os.makedirs(pathOutput + "/subscription")
    # Entrez
    TimeRelday = (datetime.datetime.now() + datetime.timedelta(days=-Relday)).strftime("%Y-%m-%d")
    Entrez.email = email
    Entrez.tool = "Biopython"
    print("Entrez.email =",email)
    # 检索：搜索term='关键词'，reldate=''最近多少天，ptyp=''文章类型
    # 例子 #hd_esearch = Entrez.esearch(db="pubmed", term="circadian arabidopsis", reldate=100, ptyp="Article", usehistory="y",RetMax="10000")
    #检索
    hd_esearch = Entrez.esearch(db="pubmed", term=TermName, reldate=Relday, usehistory="y", retmax=100000, ptyp="Article")
    read_esearch = Entrez.read(hd_esearch)
    idlist = read_esearch["IdList"]
    count = read_esearch["Count"]
    print("一共检索到" + str(count) + "篇'" + TermName + "'相关文章,现在开始下载")
    if int(count) > 0:
        # 用 efetch下载
        hd_efetch = Entrez.efetch(retstart=0, retmax=count, db="pubmed", id=idlist, rettype="medline", reldate=Relday+1, retmode="text", )

        #用Medline来解析
        parse_medline = Medline.parse(hd_efetch)
        excel = Workbook()
        table = excel.active
        table.column_dimensions['A'].width = 75
        table.column_dimensions['B'].width = 20
        table.append(["Title","Journal","IF2021","Date of Publication","Author","Type","DOI"])
        table.append(["From " + TimeRelday + " To " + TimeNow])

        #输出原始数据
        # with open("soucedata.txt", "w", encoding='utf-8') as output:
        #     output.write(str(list(parse_medline)))

        for i, ele in enumerate(list(parse_medline)):
            try:
                DOI = (''.join([x for x in ele['AID'] if '[doi]' in x]))[:-6]
                table.append([ele['TI'], ele['JT'].title(),"", ele['DP'], ", ".join(ele['AU']), ", ".join((ele['PT'])), "http://dx.doi.org/" + DOI]) #词条解析https://www.nlm.nih.gov/bsd/mms/medlineelements.html
            except:
                filename=""
                #table.append([ele['TI'], ele['JT'].title(),"", ele['DP'], ",".join(ele['AU']), str(ele['PT']), "unknown" ])
        filename = TimeNow + "_" + TermName + "_papers.xlsx"
        filename = re.sub(r'[^A-Za-z0-9 ._-]+', '', filename)
        # try:
        #     excel.save(pathOutput+"subscription\\"+filename)
        # except:
        #     print("error：请关闭excel表格重试")
    else:
        print("不执行下载")
        return filename,count

    print("下载完成，开始注释IF")
    #IF 注释
    IFdict = getIFdict()
    excelIF = load_workbook(os.getcwd() + "/IF/IF_update.xlsx")
    tableIF = excelIF.worksheets[0]  # 获取sheet
    rows = tableIF.max_row  # 获取行数
    for row in range(1, rows + 1):
        Journal = str(tableIF.cell(row=row, column=2).value)
        IF = str(tableIF.cell(row=row, column=3).value)
        IFdict.update({Journal: IF})
    # excel = load_workbook(pathOutput + "subscription\\" + filename)
    # table = excel.worksheets[0]  # 获取sheet
    rows = table.max_row  # 获取行数

    for row in range(3, rows + 1):
        Journalname = str(table.cell(row=row, column=2).value)
        getIF = IFdict.get(Journalname)
        if Journalname.find(" :") != -1:
            Journalname = Journalname[:Journalname.find(" :")]
        if getIF != None:
            table.cell(row=row, column=3).value = getIF
        elif (Journalname[0:4] == "The ") and (IFdict.get(Journalname[4:]) != None):
            table.cell(row=row, column=3).value = IFdict.get(Journalname[4:])
        elif IFdict.get(re.sub(u"\\(.*?\\)|\\{.*?}|\\[.*?]", "", Journalname)[:-1]) != None:
            table.cell(row=row, column=3).value = IFdict.get(re.sub(u"\\(.*?\\)|\\{.*?}|\\[.*?]", "", Journalname)[:-1])
        elif IFdict.get(Journalname.replace("&", "And").replace(",", "").replace(".", "-")) != None:
            table.cell(row=row, column=3).value = IFdict.get(Journalname.replace("&", "And").replace(",", "").replace(".", "-"))
        else:
            table.cell(row=row, column=3).value = 'unknown'
        # excel.save(pathOutput + "subscription\\" + filename)

    # 合并旧文档
    print("正在合并相同关键词的旧文档")
    pathOutput1 = pathOutput + "subscription\\"
    # excel = load_workbook( pathOutput1 + filename)
    # table = excel.worksheets[0]  # 获取sheet
    for file in os.listdir(pathOutput1):
        #if file != filename:
        if file[11:] ==  filename[11:]:
            wb_part = load_workbook(pathOutput1+ file)
            ws_part = wb_part.worksheets[0]  # 获取sheet
            rows = ws_part.max_row  # 获取行数
            for row in range(2, rows + 1):
                table.append(get_row_value(ws_part,row))
            os.remove(pathOutput1+ file)
    excel.save(pathOutput1 + filename)
    return filename,count


