"""开机自启动"""
import os
import win32api
import win32con,winreg,os

"""判断键是否存在"""
def Judge_Key(key_name,
              reg_root=win32con.HKEY_CURRENT_USER,#根节点  其中的值可以有：HKEY_CLASSES_ROOT、HKEY_CURRENT_USER、HKEY_LOCAL_MACHINE、HKEY_USERS、HKEY_CURRENT_CONFIG
              reg_path = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run",# 键的路径
              ):
    # print(key_name)
    """
    :param key_name: #  要查询的键名
    :param reg_root: # 根节点
#win32con.HKEY_CURRENT_USER
#win32con.HKEY_CLASSES_ROOT
#win32con.HKEY_CURRENT_USER
#win32con.HKEY_LOCAL_MACHINE
#win32con.HKEY_USERS
#win32con.HKEY_CURRENT_CONFIG
    :param reg_path: #  键的路径
    :return:feedback是（0/1/2/3：存在/不存在/权限不足/报错）
    """
    reg_flags = win32con.WRITE_OWNER | win32con.KEY_WOW64_64KEY | win32con.KEY_ALL_ACCESS
    try:
        key = winreg.OpenKey(reg_root, reg_path, 0, reg_flags)
        location, type = winreg.QueryValueEx(key, key_name)
        print("开机启动存在", "location:", location, end=', ')
        #print("开机启动已存在", "location（数据）:", location, "type:", type)
        feedback=0
    except FileNotFoundError as e:
        print("开机启动不存在", end=', ')
        feedback =1
    except PermissionError as e:
        print("权限不足",e)
        feedback = 2
    except:
        print("Error")
        feedback = 3
    return  feedback


def AutoRun(switch, zdynames ,current_file ,abspath):

    # def AutoRun(switch="open",  # 开：open # 关：close
    #             zdynames=None,
    #             current_file=None,
    #             abspath=os.path.abspath(os.path.dirname(__file__))):


    """
    :param switch: 注册表开启、关闭自启动
    :param zdynames: 当前文件名
    :param current_file: 获得文件名的前部分
    :param abspath: 当前文件路径
    :return:
    """

    path = abspath + '\\' + zdynames  # 要添加的exe完整路径如：
    judge_key = Judge_Key(reg_root=win32con.HKEY_CURRENT_USER,
                          reg_path=r"Software\Microsoft\Windows\CurrentVersion\Run",  # 键的路径
                          key_name=current_file)
    # 注册表项名
    KeyName = r'Software\Microsoft\Windows\CurrentVersion\Run'
    key = win32api.RegOpenKey(win32con.HKEY_CURRENT_USER, KeyName, 0, win32con.KEY_ALL_ACCESS)
    if switch == "open":
        # 异常处理
        try:
            if judge_key==0:
                print("无需再开启")
            elif judge_key==1:
                win32api.RegSetValueEx(key, current_file, 0, win32con.REG_SZ, path)
                win32api.RegCloseKey(key)
                print('开机自启动添加成功！')
        except:
            print('添加失败')
    elif switch =="close":
        try:
            if judge_key==0:
                win32api.RegDeleteValue(key, current_file)  # 删除值
                win32api.RegCloseKey(key)
                print('启动取消成功！')
            elif judge_key==1:print("无需取消启动")
            elif judge_key==2:print("权限不足")
            else:print("出现错误")
        except:
            print('删除失败')