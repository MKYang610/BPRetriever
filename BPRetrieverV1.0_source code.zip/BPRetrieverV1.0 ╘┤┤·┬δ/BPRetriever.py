import os
import shutil
import datetime
import win32con
import win32gui
from openpyxl import Workbook
from openpyxl import load_workbook
#################################################################################
#                                 导入子程序                                      #
#################################################################################
# 推送检索
from subscription.EntrezPubmed_subscription import *
# Pubmed 检索
from pubmed_crawler.EntrezPubmed import *
# Wos 爬虫
from wos_crawler.WosCrawlerMain import *
# 下载
from DownloadSciHub import *
# 开机启动
from AutoRun import *


#################################################################################
#                                 预设参数                                       #
#################################################################################
#工作目录预设参数
if os.path.exists('configuration0.txt'):
    pass
else:
    with open("configuration0.txt","w", encoding='UTF-8') as f:
        f.write("###### 工作目录 ######\n"+os.getcwd()+"\\output\\")
with open("configuration0.txt", "r", encoding='UTF-8') as f:
    settinglist0 = f.read().split('\n')
    pathOutput = settinglist0[1]
if not os.path.exists(pathOutput):  # 判断是否存在文件夹如果不存在则创建为文件夹
    os.makedirs(pathOutput, exist_ok=True)

#1:文献推送预设参数
if os.path.exists('configuration1.txt'):
    pass
else:
    with open("configuration1.txt","w", encoding='UTF-8') as f:
        f.write("###### 推送间隔（天） ######\n7\n###### 邮箱 ######\nexample@example.com\n###### 上次检索日期 ######\n1990-1-1\n###### 开机启动 ######\n0\n###### 启动自动检索 ######\n0\n###### 启动自动最小化 ######\n0\n###### 关键词（每行一组） ######\nmice gene editing\nmice gene therapy")
with open("configuration1.txt", "r", encoding='UTF-8') as f:
    i = 0
    TermNameList1 = []
    settinglist1 = f.read().split('\n')
    Relday1 = settinglist1[1]
    email1 = settinglist1[3]
    Timelast = settinglist1[5]
    AutoRun1 = settinglist1[7]
    AutoEntrez1 = settinglist1[9]
    AutoMin1 = settinglist1[11]
    TermNameList1 = settinglist1[13: ]


#2:pubmed预设参数
if os.path.exists('configuration2.txt'):
    pass
else:
    with open("configuration2.txt","w", encoding='UTF-8') as f:
        f.write("###### 检索几天内发表的文章（天） ######\n365\n###### 最大检索数目 ######\n1000\n###### 下载起始年份 ######\n2020\n###### 下载结束年份 ######\n2021\n###### 邮箱 ######\nexample@example.com\n###### 关键词（每行一组） ######\nmice gene editing\nmice gene therapy")
with open("configuration2.txt", "r", encoding='UTF-8') as f:
    i = 0
    TermNameList2 = []
    settinglist2 = f.read().split('\n')
    Relday2 = settinglist2[1]
    RetMax2 = settinglist2[3]
    YearMin2 = settinglist2[5]
    YearMax2 = settinglist2[7]
    email2 = settinglist2[9]
    TermNameList2 = settinglist2[11: ]

#3:wos预设参数
if os.path.exists('configuration3.txt'):
    pass
else:
    with open("configuration3.txt","w", encoding='UTF-8') as f:
        f.write("###### 检索起始年份 ######\n2020\n###### 检索结束年份 ######\n2021\n###### 最大检索数 ######\n1000\n###### 下载起始年份 ######\n2020\n###### 下载结束年份 ######\n2021\n###### 关键词（每行一组） ######\nmice gene editing")
with open("configuration3.txt", "r", encoding='UTF-8') as f:
    i = 0
    TermNameList3 = []
    settinglist3 = f.read().split('\n')
    YearFrom3 = settinglist3[1]
    YearTo3 = settinglist3[3]
    RetMax3 = settinglist3[5]
    YearMin3 = settinglist3[7]
    YearMax3 = settinglist3[9]
    TermNameList3 = settinglist3[11: ]




Website = "http://sci-hub.se/"
TimeNow = datetime.datetime.now().strftime("%Y-%m-%d")




#################################################################################
#                                 GUI程序                                       #
#################################################################################
import PySimpleGUI as sg

def main():
    global TermNameList1
    global Relday1
    global RetMax1
    global YearMin1
    global YearMax1
    global email1
    global AutoRun1
    global AutoEntrez1
    global AutoMin1


    global Relday2
    global RetMax2
    global YearMin2
    global YearMax2
    global email2
    global TermNameList2
    global pathOutput
    global pathOutputlist

    global YearFrom3
    global YearTo3
    global YearMin3
    global YearMax3
    global TermNameList3
    global RetMax3

    sg.theme('SystemDefault')
    #sg.theme('Default1')

    sg.SetOptions(
                  font=('微软雅黑', 9),
                  #background_color='white',
                  #element_background_color='#d6d7d7',
                  #text_element_background_color='LightBlue',
                  #text_color='Blue',
                  #input_text_color='Blue',
                  #button_color=('white', 'white')  # 按钮颜色，白色字，蓝色背景颜色
                  )

# 三级界面
    #选项卡1
    tab1col1 = [[sg.Text('关键词', size=(16, 1))],
                [sg.Multiline("\n".join(TermNameList1), key='_TermNameList1_', size=(30, 10))],
               ]

    tab1col2 = [[sg.Text('', size=(1, 1)),sg.Text('检索间隔天数', size=(17,1)),sg.Text('使用者邮箱(仅做为检索时的用户名)', size=(30, 1))],
                [sg.Text('', size=(1, 1)),sg.Input(key='_Relday1_',default_text = Relday1, size=(10, 1)),sg.Text('', size=(5, 1)), sg.Input(default_text =email1 , key='_email1_', size=(25, 1))],
                [sg.Text('', size=(12, 1)),sg.Button('开始检索', size=(20, 1))],
                [sg.Text('', size=(1, 1))],
                #开机启动报错，该bug暂未解决
                #[sg.Text('', size=(3, 1)),sg.Checkbox('开机启动', key='_AutoRun_', default=bool(int(AutoRun1))), sg.Text('', size=(5, 1)),sg.Checkbox('启动后最小化', key='_AutoMin_', default=bool(int(AutoMin1)))],
                [sg.Text('', size=(3, 1)),  sg.Checkbox('启动后最小化', key='_AutoMin_', default=bool(int(AutoMin1))),sg.Text('', size=(35,1))],
                [sg.Text('', size=(3, 1)),sg.Checkbox('启动后自动检索(若距离上次检索时间超过设定值)', key='_AutoEnz_', default=bool(int(AutoEntrez1)))],
                [sg.Text('', size=(10, 1)),sg.Button('应用设置(开启定期推送功能)', size=(25, 1))]
               ]

    #选项卡2
    # 选项卡3
    tab2col1 = [[sg.Text('关键词(换行符分割多条检索式)'), sg.Button('?',key='?p',border_width=0,button_color=('black','#f0f0f0'))],
                [sg.Multiline("\n".join(TermNameList2), key='_TermNameList2_', size=(30, 10))],
               ]

    tab2col2 = [[sg.Text('检索几天内发表的文章', size=(18,1)),sg.Text('最大检索数', size=(16, 1)),sg.Text('使用者邮箱(ID)', size=(17, 1))],
                [sg.Input(key='_Relday2_',default_text = Relday2, size=(10, 1)),sg.Text('', size=(5, 1)), sg.Input(key='_RetMax2_',default_text = RetMax2, size=(10, 1)),sg.Text('', size=(5, 1)), sg.Input(default_text =email2 , key='_email2_', size=(15, 1))],
                [sg.Text('', size=(12, 1)),sg.Button('从Pubmed数据库检索文章', size=(20, 1))],
                [sg.Text('', size=(1, 1))],
                [sg.Text('下载起始年份', size=(17,1)), sg.Text('下载结束年份', size=(17,1)), sg.Text('Scihub网址', size=(17,1))],
                [sg.Input(key='_YearMin2_',default_text = YearMin2, size=(10, 1)),sg.Text('', size=(5, 1)), sg.Input(key='_YearMax2_',default_text = YearMax2, size=(10, 1)),sg.Text('', size=(5, 1)),sg.Combo(["http://sci-hub.se/", "http://sci-hub.ren/", "http://sci-hub.tw/","http://sci-hub.is/", "http://sci-hub.shop/"], default_value="http://sci-hub.se/",key='_WebSite2_', size=(15, 1))],
                [sg.Text('', size=(12, 1)),sg.Button('从Scihub批量下载原文',key=('Download2'), size=(20, 1))],
               ]

    # 选项卡3
    tab3col1 = [[sg.Text('关键词(仅支持一条检索式)'), sg.Button('?',key='?w',border_width=0,button_color=('black','#f0f0f0'))],
                [sg.Multiline("\n".join(TermNameList3), key='_TermNameList3_', size=(30, 10))],
               ]

    tab3col2 = [[sg.Text('检索起始年份', size=(17,1)),sg.Text('检索结束年份', size=(17,1)),sg.Text('最大检索数', size=(12, 1))],
                [sg.Input(key='_YearFrom3_',default_text = YearFrom3, size=(10, 1)),sg.Text('', size=(5, 1)), sg.Input(key='_YearTo3_',default_text = YearTo3, size=(10, 1)),sg.Text('', size=(5,1)),sg.Input(key='_RetMax3_',default_text = RetMax3, size=(10, 1))],
                [sg.Text('', size=(12, 1)),sg.Button('从Wos数据库检索文章', size=(20, 1))],
                [sg.Text('', size=(1, 1))],
                [sg.Text('下载起始年份', size=(17,1)), sg.Text('下载结束年份', size=(17,1)), sg.Text('Scihub网址', size=(17,1))],
                [sg.Input(key='_YearMin3_',default_text = YearMin3, size=(10, 1)),sg.Text('', size=(5, 1)), sg.Input(key='_YearMax3_',default_text = YearMax3, size=(10, 1)),sg.Text('', size=(5, 1)),sg.Combo(["http://sci-hub.se/", "http://sci-hub.ren/", "http://sci-hub.tw/","http://sci-hub.is/", "http://sci-hub.shop/"], default_value="http://sci-hub.se/",key='_WebSite3_', size=(15, 1))],
                [sg.Text('', size=(12, 1)),sg.Button('从Scihub批量下载原文',key=('Download3'), size=(20, 1))],
               ]

    # 选项卡4
    tab4col1 = [[sg.Text('此处输入DOI(换行符分割)')],
                [sg.Multiline("DOI1\nDOI2\nDOI3", key='_TermNameList4_', size=(50, 10))],
               ]

    tab4col2 = [[sg.Text('', size=(1, 1)),sg.Text('Scihub网址', size=(32,1))],
                [sg.Text('', size=(1, 1)),sg.Combo(["http://sci-hub.se/", "http://sci-hub.ren/", "http://sci-hub.tw/","http://sci-hub.is/", "http://sci-hub.shop/"], default_value="http://sci-hub.se/",key='_WebSite4_', size=(17, 1))],
                [sg.Text('', size=(1, 1)),sg.Button('开始下载', size=(20, 1),key=('Download4'))],
               ]

#二级界面
    # 选项卡1
    frame1_layout = [[sg.Column(tab1col1), sg.Column(tab1col2)]]
    tab1_layout = [[sg.Frame('', frame1_layout)]]

    # 选项卡2
    frame2_layout = [[sg.Column(tab2col1), sg.Column(tab2col2)]]
    tab2_layout = [[sg.Frame('',frame2_layout)]]

    # 选项卡3
    frame3_layout = [[sg.Column(tab3col1), sg.Column(tab3col2)]]
    tab3_layout = [[sg.Frame('',frame3_layout)]]

    # 选项卡4
    frame4_layout = [[sg.Column(tab4col1), sg.Column(tab4col2)]]
    tab4_layout = [[sg.Frame('',frame4_layout)]]

#一级界面
    frame4_layout = [[sg.Output(size=(91, 12), background_color=("black"),text_color='white',echo_stdout_stderr = True)],
                     ]
    layout = [[sg.TabGroup([[sg.Tab('Papers 定期推送', tab1_layout), sg.Tab('Pubmed 检索', tab2_layout), sg.Tab('Web of science 检索', tab3_layout),sg.Tab('通过Doi批量下载文献', tab4_layout)]],font=('微软雅黑 light', 10),border_width=0)],
              [sg.Frame('日志', frame4_layout)],
              [sg.Button('打开目录'),sg.FolderBrowse('改变目录', target = '_pathOutput_'),sg.Input(key='_pathOutput_',default_text=pathOutput,size=(40, 12)),sg.Text('', size=(26, 1)),sg.Button('重置',button_color=("black","#c3c3c3"))],
              ]

    window = sg.Window('Batch Paper Retriever v1.0 (developed by MK)', layout, icon='BPR.ico') #background_color="white"


    window.Read(timeout=10)
    ############### 开机检索 ###########
    try:
        if bool(int(AutoMin1)) == True:
            # 查找窗口句柄
            #hwnd = win32gui.FindWindow("TkTopLevel", u"Batch Paper Retriever v1.0 (developed by MK)")
            hwnd = win32gui.GetForegroundWindow()
            if hwnd != 0:
                win32gui.ShowWindow(hwnd, win32con.SW_SHOWMINIMIZED)#最小化

        if bool(int(AutoEntrez1)) == True:

            # 计算记录上次检索有几天
            d1 = datetime.datetime.now().strftime("%Y-%m-%d")
            d1 = datetime.datetime.strptime(d1, '%Y-%m-%d')
            d2 = datetime.datetime.strptime(Timelast, '%Y-%m-%d')
            delta = d1 - d2
            TermNameList1 = [i for i in TermNameList1 if i != ""]
            Relday1 = int(Relday1)
            T1 = time.perf_counter()
            filenamelist = []
            countlist = []
            if delta.days >= Relday1:
                if delta.days > 365:
                    day = Relday1
                else:
                    day = delta.days
                print("上一次检索于", Timelast)
                print("开始新的检索：\n")
                if email1 == 'example@example.com':
                    print('error:请输入自己的邮箱')
                    pass
                else:
                    for TermName in TermNameList1:
                        resultlist = EntrezPubmed_subscription(TermName, TimeNow, day, email1, pathOutput)
                        filenamelist.append(resultlist[0])
                        countlist.append(resultlist[1])
                    T2 = time.perf_counter()
                    print('检索完成,运行时间:%s秒' % round((T2 - T1), 2)+ "\n")
                    with open("configuration1.txt", "w", encoding='UTF-8') as f:  # 记录检查成功日期
                        settinglist1[5] = str(TimeNow)
                        setting1 = '\n'.join(settinglist1)
                        f.write(setting1)
                    # 生成弹框报告
                    text = ''
                    for i in range(0, len(countlist)):
                        text = text + "%s篇“%s”相关文章\n" % (countlist[i], filenamelist[i][11:-12])
                    text = '最近%s天新发表了：\n%s\n是否打开表格查看文献?' % (day, text)
                    yes_no = sg.popup_yes_no(text,icon='BPR.ico', title="检索报告", grab_anywhere=True, keep_on_top=True )
                    if yes_no == "Yes":
                        hwnd = win32gui.GetForegroundWindow()
                        if hwnd != 0:
                            win32gui.ShowWindow(hwnd, win32con.SW_SHOWMINIMIZED) # 最小化
                        for filename in filenamelist:
                            os.startfile(pathOutput + "subscription\\" + filename)
            else:
                print("上一次检索于",Timelast)
                print("时间未到,无需检索\n")
    except:
        print('error:自动检索报错！')
        print('若找不到报错原因,请重置软件')




# Event Loop

    while True:
        try:
            event, values = window.Read()

            if event in (None, 'Exit'):
                break
            elif event == '打开目录':
                os.startfile(pathOutput)
            elif event == '从Pubmed数据库检索文章':
                if not os.path.exists(pathOutput + "/pubmed"):  # 判断是否存在文件夹如果不存在则创建为文件夹
                    os.makedirs(pathOutput + "/pubmed")
                print("正在检索：")
                TermNameList2 = values['_TermNameList2_'].split("\n")
                TermNameList2 = [i for i in TermNameList2 if i != ""]
                Relday2 = int(values['_Relday2_'])
                RetMax2 = int(values['_RetMax2_'])
                YearMin2 = int(values['_YearMin2_'])
                YearMax2 = int(values['_YearMax2_'])
                email2 = values['_email2_']
                with open("configuration2.txt", "w", encoding='UTF-8') as f:
                    settinglist2[1] = str(Relday2)
                    settinglist2[3] = str(RetMax2)
                    settinglist2[5] = str(YearMin2)
                    settinglist2[7] = str(YearMax2)
                    settinglist2[9] = str(email2)
                    settinglist2[11:] = TermNameList2
                    setting2 = '\n'.join(settinglist2)
                    f.write(setting2)
                with open("configuration0.txt", "w", encoding='UTF-8') as f:
                    pathOutput = str(values['_pathOutput_'])
                    settinglist0[1] = pathOutput
                    setting0 = '\n'.join(settinglist0)
                    f.write(setting0)
                T1 = time.perf_counter()
                for TermName in TermNameList2:
                    EntrezPubmed(TermName,TimeNow,Relday2,RetMax2,email2,pathOutput)
                T2 = time.perf_counter()
                print('检索完成,运行时间:%s秒' % round((T2 - T1), 2), "\n")

            elif event == '从Wos数据库检索文章':
                if not os.path.exists(pathOutput + "/wos"):  # 判断是否存在文件夹如果不存在则创建为文件夹
                    os.makedirs(pathOutput + "/wos")
                print("正在检索：")
                TermNameList3 = values['_TermNameList3_'].split("\n")
                TermNameList3 = [i for i in TermNameList3 if i != ""]
                TermNameList3=TermNameList3[0]
                YearFrom3 = int(values['_YearFrom3_'])
                YearTo3 = int(values['_YearTo3_'])
                YearMin3 = int(values['_YearMin3_'])
                YearMax3 = int(values['_YearMax3_'])
                RetMax3 = int(values['_RetMax3_'])
                with open("configuration3.txt", "w", encoding='UTF-8') as f:
                    settinglist3[1] = str(YearFrom3)
                    settinglist3[3] = str(YearTo3)
                    settinglist3[5] = str(RetMax3)
                    settinglist3[7] = str(YearMin3)
                    settinglist3[9] = str(YearMax3)
                    settinglist3[11] = TermNameList3
                    setting3 = '\n'.join(settinglist3)
                    f.write(setting3)
                with open("configuration0.txt", "w", encoding='UTF-8') as f:
                    pathOutput = str(values['_pathOutput_'])
                    settinglist0[1] = pathOutput
                    setting0 = '\n'.join(settinglist0)
                    f.write(setting0)
                T1 = time.perf_counter()
                Keyword = TermNameList3
                if "=" not in TermNameList3:
                    Keyword = 'TS=(%s)'%TermNameList3
                crawl_by_query(query='(%s) AND PY=(%s-%s)'%(Keyword,YearFrom3,YearTo3))
                pathOutput3 = pathOutput + "wos\\"
                WOSgetIF(pathOutput3)
                T2 = time.perf_counter()
                print('检索完成,运行时间:%s秒' % round((T2 - T1), 2), "\n")

            elif event == '?p':
                sg.popup('高级检索式示例:\nhuman[TI] AND ((tumour[TI]) OR (immune[TI]))\n\n部分缩略词：\n不加限定词=ALL Fields\nAB=摘要\nTI=标题\nAU=作者\nJT=杂志名称',title="检索提示")
            elif event == '?w':
                sg.popup('高级检索式示例：\nTS = human AND  (TS = tumour OR TS = immune)\n\n部分缩略词：\nAB=摘要\nTI=标题\nTS=主题\nAU=作者\nSO=杂志名称\nDO=DOI',title="检索提示")

            elif event == 'Download2':
                print("正在下载pubmed目录下所有xlsx的原文：")
                TermNameList2 = values['_TermNameList2_'].split("\n")
                TermNameList2 = [i for i in TermNameList2 if i != ""]
                Relday2 = int(values['_Relday2_'])
                RetMax2 = int(values['_RetMax2_'])
                YearMin2 = int(values['_YearMin2_'])
                YearMax2 = int(values['_YearMax2_'])
                email2 = values['_email2_']
                with open("configuration2.txt", "w", encoding='UTF-8') as f:
                    settinglist2[1] = str(Relday2)
                    settinglist2[3] = str(RetMax2)
                    settinglist2[5] = str(YearMin2)
                    settinglist2[7] = str(YearMax2)
                    settinglist2[9] = str(email2)
                    settinglist2[11:] = TermNameList2
                    setting2 = '\n'.join(settinglist2)
                    f.write(setting2)
                with open("configuration0.txt", "w", encoding='UTF-8') as f:
                    pathOutput = str(values['_pathOutput_'])
                    settinglist0[1] = pathOutput
                    setting0 = '\n'.join(settinglist0)
                    f.write(setting0)
                T1 = time.perf_counter()
                i = 0
                RunResult = ""
                pathOutput2 = pathOutput + "pubmed"
                for file in os.listdir(pathOutput2):
                    if '.xlsx' in file:
                        Result = DownloadSciHub(file, event, YearMin2, YearMax2, values['_WebSite2_'], i, pathOutput)
                        i = Result[1]
                        RunResult = RunResult + Result[0]
                T2 = time.perf_counter()
                print('下载完成,运行时间:%s秒\n' % round((T2 - T1), 2) + RunResult + '\n')

            elif event == 'Download3':
                print("正在下载wos目录下所有xlsx的原文：")
                TermNameList3 = values['_TermNameList3_'].split("\n")
                TermNameList3 = [i for i in TermNameList3 if i != ""]
                TermNameList3 = TermNameList3[0]
                YearFrom3 = int(values['_YearFrom3_'])
                YearTo3 = int(values['_YearTo3_'])
                RetMax3 = int(values['_RetMax3_'])
                YearMin3 = int(values['_YearMin3_'])
                YearMax3 = int(values['_YearMax3_'])
                with open("configuration3.txt", "w", encoding='UTF-8') as f:
                    settinglist3[1] = str(YearFrom3)
                    settinglist3[3] = str(YearTo3)
                    settinglist3[5] = str(RetMax3)
                    settinglist3[7] = str(YearMin3)
                    settinglist3[9] = str(YearMax3)
                    settinglist3[11] = TermNameList3
                    setting3 = '\n'.join(settinglist3)
                    f.write(setting3)
                with open("configuration0.txt", "w", encoding='UTF-8') as f:
                    pathOutput = str(values['_pathOutput_'])
                    settinglist0[1] = pathOutput
                    setting0 = '\n'.join(settinglist0)
                    f.write(setting0)
                T1 = time.perf_counter()
                i = 0
                RunResult = ""
                pathOutput3 = pathOutput + "wos\\"
                for file in os.listdir(pathOutput3):
                    if '.xlsx' in file:
                        Result = DownloadSciHub(file, event, YearMin3, YearMax3, values['_WebSite3_'], i, pathOutput)
                        i = Result[1]
                        RunResult = RunResult + Result[0]
                T2 = time.perf_counter()
                print('下载完成,运行时间:%s秒\n' % round((T2 - T1), 2) + RunResult + '\n')

            elif event == 'Download4':
                print("开始下载")
                pathOutput4 = pathOutput + "doi_Download\\"
                if not os.path.exists(pathOutput4):  # 判断是否存在文件夹如果不存在则创建为文件夹
                    os.makedirs(pathOutput4)
                TermNameList4 = values['_TermNameList4_'].split("\n")
                excel = Workbook()
                table = excel.active
                for i in range(1,len(TermNameList4)):
                    table.cell(row=i, column=1).value = TermNameList4[i-1]
                excel.save(pathOutput4 + TimeNow +"_doi_Download_result.xlsx")

                T1 = time.perf_counter()
                RunResult = ""
                #参数预赋值
                file = TimeNow +"_doi_Download_result.xlsx"
                YearMin4 = 0
                YearMax4 = 0
                i= 0
                Result = DownloadSciHub(file, event, YearMin4, YearMax4, values['_WebSite4_'],i , pathOutput)
                i = Result[1]
                RunResult = RunResult + Result[0]
                T2 = time.perf_counter()
                print('下载完成,运行时间:%s秒\n' % round((T2 - T1), 2) + RunResult + '\n')

            elif event == '应用设置(开启定期推送功能)':
                zdynames='BPRetriever.exe' #当前文件名
                current_file='BPRetriever' #获得文件名的前部分(键名)
                abspath = os.getcwd()
                # if values['_AutoRun_'] == True:  #开机启动报错，该bug暂未解决
                #     AutoRun('open', zdynames, current_file, abspath)
                # if values['_AutoRun_'] == False:
                #     AutoRun('close', zdynames, current_file, abspath)
                print("启动最小化：", values['_AutoMin_'])
                print("启动自动检索：", values['_AutoEnz_'],'\n')
                with open("configuration1.txt", "w", encoding='UTF-8') as f:
                    #settinglist1[7] = str(int(values['_AutoRun_'])) #开机启动报错，该bug暂未解决
                    settinglist1[9] = str(int(values['_AutoEnz_']))
                    settinglist1[11] = str(int(values['_AutoMin_']))
                    setting1 = '\n'.join(settinglist1)
                    f.write(setting1)
                pass

            elif event == '开始检索':
                #计算记录上次检索有几天
                d1 = datetime.datetime.now().strftime("%Y-%m-%d")
                d1 = datetime.datetime.strptime(d1, '%Y-%m-%d')
                d2 = datetime.datetime.strptime(Timelast, '%Y-%m-%d')
                delta = d1 - d2
                print("正在检索：")
                TermNameList1 = values['_TermNameList1_'].split("\n")
                TermNameList1 = [i for i in TermNameList1 if i != ""]
                Relday1 = int(values['_Relday1_'])
                email1 = values['_email1_']
                with open("configuration1.txt", "w", encoding='UTF-8') as f:
                    settinglist1[1] = str(Relday1)
                    settinglist1[3] = str(email1)
                    settinglist1[13:] = TermNameList1
                    setting1 = '\n'.join(settinglist1)
                    f.write(setting1)
                with open("configuration0.txt", "w", encoding='UTF-8') as f:
                    pathOutput = str(values['_pathOutput_'])
                    settinglist0[1] = pathOutput
                    setting0 = '\n'.join(settinglist0)
                    f.write(setting0)
                T1 = time.perf_counter()
                filenamelist=[]
                countlist=[]
                if email1 == 'example@example.com':
                    print('error:请输入自己的邮箱')
                    pass
                else:
                    day = Relday1  # 取上次检索天数与设置天数的最大值
                    for TermName in TermNameList1:
                        resultlist = EntrezPubmed_subscription(TermName,TimeNow,day,email1,pathOutput)
                        filenamelist.append(resultlist[0])
                        countlist.append(resultlist[1])
                    T2 = time.perf_counter()
                    print('检索完成,运行时间:%s秒' % round((T2 - T1), 2), "\n")
                    with open("configuration1.txt", "w", encoding='UTF-8') as f:#记录检查成功日期
                        settinglist1[5] = str(TimeNow)
                        setting1 = '\n'.join(settinglist1)
                        f.write(setting1)
                    #生成弹框报告
                    text=''
                    for i in range(0,len(countlist)):
                        text= text+"%s篇“%s”相关文章\n"%(countlist[i],filenamelist[i][11:-12])
                    text ='最近%s天新发表了：\n%s\n是否打开表格查看文献?'%(Relday1,text)
                    yes_no = sg.popup_yes_no(text,icon='BPR.ico', title="检索报告", grab_anywhere=True, keep_on_top=True )
                    if yes_no == "Yes":
                        for filename in filenamelist:
                            os.startfile(pathOutput + "subscription\\" + filename)
            elif event == '重置':
                yes_no = sg.popup_yes_no("若发现bug请反馈至yangmk610@outlook.com\n\n重置将删除目录中数据，请提前备份\n是否重置?", icon='BPR.ico', title="是否恢复默认设置", grab_anywhere=True, keep_on_top=True)
                if yes_no == "Yes":
                    try:
                        shutil.rmtree(pathOutput + "subscription")
                    except:
                        pass
                    try:
                        shutil.rmtree(pathOutput + "wos")
                    except:
                        pass
                    try:
                        shutil.rmtree(pathOutput + "pubmed")
                    except:
                        pass
                    try:
                        shutil.rmtree(pathOutput + "doi_Download")
                    except:
                        pass
                    try:
                        os.remove(os.getcwd()+ "\\configuration0.txt")
                    except:
                        pass
                    try:
                        os.remove(os.getcwd() + "\\configuration1.txt")
                    except:
                        pass
                    try:
                        os.remove(os.getcwd() + "\\configuration2.txt")
                    except:
                        pass
                    try:
                        os.remove(os.getcwd() + "\\configuration3.txt")
                    except:
                        pass
                    print('重置完成,请重启软件')
        except:
            print('error:程序报错！')
            print('若找不到报错原因,请重置软件')



    window.Close()

    # time.sleep(100)




main()