
from scrapy import cmdline

from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings


import os
from openpyxl import Workbook
from openpyxl import load_workbook
from IF.IF2020 import *
import re




def crawl_by_query(query):
    try:
        # 引用spider
        from wos_crawler.spiders.wos_advanced_query_spider import WosAdvancedQuerySpiderSpider
        # 执行spider
        settings = get_project_settings()
        process = CrawlerProcess(settings=settings)
        process.crawl(WosAdvancedQuerySpiderSpider, query=query,output_path='/wos', document_type='Article', output_format='bibtex', sid='')
        process.start()
    except Exception as e:
        print(e)
        print("error:检索失败,再次检索需重启软件")

     # try:
     #    cmdline.execute(
     #        r'scrapy crawl wos_advanced_query_spider -a output_path={} -a output_format={}'.format(output_path, output_format).split() +
     #        ['-a', 'query={}'.format(query), '-a', 'document_type={}'.format(document_type), '-a', 'sid={}'.format(sid)]
     #    )
     # except Exception as e:
     #     print(e)
     #     print("error:检索失败,再次检索需重启软件")


def WOSgetIF(pathOutput3):
    print("下载完成，开始注释IF")

    excel = Workbook()
    table = excel.active
    table.column_dimensions['A'].width = 75
    table.column_dimensions['B'].width = 20
    table.append(["Title", "Journal", "IF2021", "Date of Publication", "Author", "Times of Cited", "DOI"])

    for file in os.listdir(pathOutput3):
        if file[-5:] == ".xlsx" and file[0:4] =="part":
            wb_part = load_workbook(pathOutput3+ file)
            ws_part = wb_part.worksheets[0]  # 获取sheet
            rows = ws_part.max_row  # 获取行数
            for row in range(1, rows + 1):
                table.append(get_row_value(ws_part,row))
            os.remove(pathOutput3+ file)

            # IF 注释
            IFdict = getIFdict()
            excelIF = load_workbook(os.getcwd() + "/IF/IF_update.xlsx")
            tableIF = excelIF.worksheets[0]  # 获取sheet
            rows = tableIF.max_row  # 获取行数
            for row in range(1, rows + 1):
                Journal = str(tableIF.cell(row=row, column=2).value)
                IF = str(tableIF.cell(row=row, column=3).value)
                IFdict.update({Journal: IF})

            rows = table.max_row  # 获取行数
            for row in range(2, rows + 1):
                Journalname = str(table.cell(row=row, column=2).value)
                getIF = IFdict.get(Journalname)
                if Journalname.find(" :") != -1:
                    Journalname = Journalname[:Journalname.find(" :")]
                if getIF != None:
                    table.cell(row=row, column=3).value = getIF
                elif (Journalname[0:4] == "The ") and (IFdict.get(Journalname[4:]) != None):
                    table.cell(row=row, column=3).value = IFdict.get(Journalname[4:])
                elif IFdict.get(re.sub(u"\\(.*?\\)|\\{.*?}|\\[.*?]", "", Journalname)[:-1]) != None:
                    table.cell(row=row, column=3).value = IFdict.get(re.sub(u"\\(.*?\\)|\\{.*?}|\\[.*?]", "", Journalname)[:-1])
                elif IFdict.get(Journalname.replace("&", "And").replace(",", "").replace(".", "-")) != None:
                    table.cell(row=row, column=3).value = IFdict.get(Journalname.replace("&", "And").replace(",", "").replace(".", "-"))
                else:
                    table.cell(row=row, column=3).value = 'unknown'
            filename = file[6:]
            excel.save(pathOutput3 + filename)

def get_row_value(self, row):
    columns = self.max_column
    row_data = []
    for i in range(1, columns + 1):
        cell_value = self.cell(row=row, column=i).value
        row_data.append(cell_value)
    return row_data


