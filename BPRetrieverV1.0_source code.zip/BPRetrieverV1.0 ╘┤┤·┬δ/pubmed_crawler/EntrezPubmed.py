from Bio import Entrez
from Bio import Medline
import datetime
from openpyxl import Workbook
from openpyxl import load_workbook
import re
import os
from IF.IF2020 import *


def EntrezPubmed(TermName,TimeNow,Relday,RetMax,email,pathOutput):#检索
    # Entrez
    TimeRelday = (datetime.datetime.now() + datetime.timedelta(days=-Relday - 1)).strftime("%Y-%m-%d")
    if email == 'example@example.com':
        print('error:请输入自己的邮箱')
        return
    Entrez.email = email
    Entrez.tool = "Biopython"
    print("Entrez.email =", email)

    # 检索：搜索term='关键词'，reldate=''最近多少天，ptyp=''文章类型
    # 例子 #hd_esearch = Entrez.esearch(db="pubmed", term="circadian arabidopsis", reldate=100, ptyp="Article", usehistory="y",RetMax="10000")
    #检索
    hd_esearch = Entrez.esearch(db="pubmed", term=TermName, reldate=Relday+1, usehistory="y", retmax=RetMax, ptyp="Article")
    read_esearch = Entrez.read(hd_esearch)
    idlist = read_esearch["IdList"]
    count = read_esearch["Count"]
    count = min(int(count),RetMax)
    print("一共检索到" + str(count) + "篇'" + TermName + "'相关文章,现在开始下载")
    if int(count) > 0:
        # 用 efetch下载
        hd_efetch = Entrez.efetch(retstart=0, retmax=count, db="pubmed", id=idlist, rettype="medline", reldate=Relday, retmode="text", )

        #用Medline来解析
        parse_medline = Medline.parse(hd_efetch)
        wb = Workbook()
        ws = wb.active
        ws.column_dimensions['A'].width = 75
        ws.column_dimensions['B'].width = 20
        ws.append(["Title", "Journal", "IF2021", "Date of Publication", "Author", "Type", "DOI"])
        ws.append(["From "+TimeRelday+" To "+TimeNow])


        #输出原始数据
        # with open("soucedata.txt", "w", encoding='utf-8') as output:
        #     output.write(str(list(parse_medline)))

        for i, ele in enumerate(list(parse_medline)):
            try:
                DOI = (''.join([x for x in ele['AID'] if '[doi]' in x]))[:-6]
                ws.append([ele['TI'], ele['JT'].title(),"", ele['DP'], ", ".join(ele['AU']), ", ".join((ele['PT'])), "http://dx.doi.org/" + DOI]) #词条解析https://www.nlm.nih.gov/bsd/mms/medlineelements.html
            except:
                filename=""
                #ws.append([ele['TI'], ele['JT'].title(),"", ele['DP'], ",".join(ele['AU']), str(ele['PT']), "unknown" ])
        filename = TimeNow + "_" + TermName + "_papers.xlsx"
        filename = re.sub(r'[^A-Za-z0-9 ._-]+', '', filename)
        try:
            wb.save(pathOutput+"pubmed\\"+filename)
        except:
            print("error：请关闭excel表格重试")
    else:
        print("不执行下载")
    print("下载完成，开始注释IF")

    #IF 注释
    IFdict = getIFdict()
    excelIF = load_workbook(os.getcwd() + "/IF/IF_update.xlsx")
    tableIF = excelIF.worksheets[0]  # 获取sheet
    rows = tableIF.max_row  # 获取行数
    for row in range(1, rows + 1):
        Journal = str(tableIF.cell(row=row, column=2).value)
        IF = str(tableIF.cell(row=row, column=3).value)
        IFdict.update({Journal: IF})
    excel = load_workbook(pathOutput + "pubmed\\" + filename)
    table = excel.worksheets[0]  # 获取sheet
    rows = table.max_row  # 获取行数

    for row in range(3, rows + 1):
        Journalname = str(table.cell(row=row, column=2).value)
        getIF = IFdict.get(Journalname)
        if Journalname.find(" :") != -1:
            Journalname = Journalname[:Journalname.find(" :")]
        if getIF != None:
            table.cell(row=row, column=3).value = getIF
        elif (Journalname[0:4] == "The ") and (IFdict.get(Journalname[4:]) != None):
            table.cell(row=row, column=3).value = IFdict.get(Journalname[4:])
        elif IFdict.get(re.sub(u"\\(.*?\\)|\\{.*?}|\\[.*?]", "", Journalname)[:-1]) != None:
            table.cell(row=row, column=3).value = IFdict.get(re.sub(u"\\(.*?\\)|\\{.*?}|\\[.*?]", "", Journalname)[:-1])
        elif IFdict.get(Journalname.replace("&", "And").replace(",", "").replace(".", "-")) != None:
            table.cell(row=row, column=3).value = IFdict.get(Journalname.replace("&", "And").replace(",", "").replace(".", "-"))
        else:
            table.cell(row=row, column=3).value = 'unknown'
        excel.save(pathOutput + "pubmed\\" + filename)
